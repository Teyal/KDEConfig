# KDEConfig
My personal KDE desktop configutarion.
