# Generated script, do not edit
# Exports language-format specific env vars from startkde.
# This script has been generated from kcmshell5 formats.
# It will automatically be overwritten from there.
export LANG=en_US.UTF-8
export LC_NUMERIC=pt_BR.UTF-8
export LC_TIME=pt_BR.UTF-8
export LC_MONETARY=pt_BR.UTF-8
export LC_MEASUREMENT=pt_BR.UTF-8
